Place the following files in this lib/ folder for fully-offline operation.
Download each file once from the URLs below (requires internet access once only).

──────────────────────────────────────────────────────────────────────────────
FILE 1 – globe.gl   (PRIMARY 3-D globe renderer)
──────────────────────────────────────────────────────────────────────────────
Save as:  lib/globe.gl.min.js

Download:
  https://cdn.jsdelivr.net/npm/globe.gl/dist/globe.gl.min.js

Command (macOS / Linux):
  curl -L "https://cdn.jsdelivr.net/npm/globe.gl/dist/globe.gl.min.js" \
       -o "lib/globe.gl.min.js"

──────────────────────────────────────────────────────────────────────────────
FILE 2 – countries.geojson   (accurate country border polygons)
──────────────────────────────────────────────────────────────────────────────
Save as:  lib/countries.geojson

Download (this is the same file used by globe.gl's own examples):
  https://raw.githubusercontent.com/vasturiano/globe.gl/master/example/world-countries/countries.json

Command (macOS / Linux):
  curl -L "https://raw.githubusercontent.com/vasturiano/globe.gl/master/example/world-countries/countries.json" \
       -o "lib/countries.geojson"

──────────────────────────────────────────────────────────────────────────────
FILE 3 – three.min.js   (fallback – only needed if globe.gl is missing)
──────────────────────────────────────────────────────────────────────────────
Save as:  lib/three.min.js

Download:
  https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js

──────────────────────────────────────────────────────────────────────────────
FALLBACK CHAIN
──────────────────────────────────────────────────────────────────────────────
globe.gl present           → beautiful 3-D globe with real country borders,
                             continent & ocean labels, atmosphere, graticules
globe.gl absent + THREE    → Three.js globe with simplified continent texture
both absent                → 2-D orthographic canvas globe
